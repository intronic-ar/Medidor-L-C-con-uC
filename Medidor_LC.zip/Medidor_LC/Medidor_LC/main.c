#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
//#include <math.h>
#include <avr/interrupt.h>

#include "LCD.h"
#include "twi_master.h"
#include "ADC.h"


volatile uint16_t captura;


//long T = 1000; // uS para 50 Hz
//long Ts = 100;
//long Ciclos = 4;
//long numSamples = T * Ciclos / Ts;
long numSamples = 40;

float adc_raw;
float sumatoria = 0.0;
uint16_t sum = 0;
float V_rms = 0.0;
float I_rms = 0.0;
float I_promedio = 0.0;
float V_promedio = 0.0;
float Z = 0.0;
float XL = 0.0;

float L = 0.0;

float XC = 0.0;

float C_ = 0.0;

int main(void)
{
	TCCR1B |= (1 << ICES1);			// ICP con flanco de subida
	TCCR1B |= (1 << CS11);			// Prescaler = T = (1 / (16.000.000 / 8) )= 0.5 uS
	TCCR1B |= (1 << ICNC1);
	TIMSK1 |= (1 << ICIE1);			// ICP interrupt habilitado
	TCNT1 = 0;						// Arranca el timer en cero
	sei();

	tw_init(TW_FREQ_100K, true);
	lcd_init();
	ADC_init();
/*		
	for (int i=15; i>=0; i--)
	{
		lcd_cmd(CLEAR);
		lcd_cmd(LINEA1 + i);
		lcd_string("intronic.com.ar");
		_delay_ms(500);
	}
	_delay_ms(1500);
	lcd_cmd(CLEAR);
	*/

	for (int i = 1; i <= 250; i++)
	{
		I_promedio += (ADC_read(0) * 4.89 / 1023.0) / 250.0;
		_delay_us(250);;
	}
	
	for (int i = 1; i <= 250; i++)
	{
		V_promedio += (ADC_read(1) * 4.89 / 1023.0) / 250.0;
		_delay_us(250);;
	}
 
	while (1) 
	{
		cli();
		float angulo = (captura * 0.505) * 0.36;		// 90/250 = 0,36 (1 KHz --> T = 1 ms  |   90�   ---> 250 us)
		char med[5];
		sei();
		
	
		I_rms = 0.0;
		sumatoria = 0.0;
		sum = 0;

		while (sum < numSamples)
		{
			adc_raw = (ADC_read(0) * 4.89 / 1023.0) - I_promedio;
			sumatoria += adc_raw * adc_raw;
			sum++;
			_delay_us(100);
		}

		I_rms = (sqrt(sumatoria / numSamples)) / 50.0;
		
		V_rms = 0.0;
		sumatoria = 0.0;
		sum = 0;

		while (sum < numSamples)
		{
			adc_raw = (ADC_read(1) * 4.89 / 1023.0) - V_promedio;
			sumatoria += adc_raw * adc_raw;
			sum++;
			_delay_us(100);
		}

		V_rms = (sqrt(sumatoria / numSamples)) / 3.0 ;
		
		Z = V_rms / I_rms;

	
		XL = Z * sin(angulo * M_PI / 180.0); // Pasar el �ngulo a rad.
		
		L = XL / (2 * M_PI * 1000.0 ) * 1000.0;
		
		dtostrf(L, 3, 2, med);
		lcd_cmd(CLEAR);
		lcd_cmd(LINEA1 + 2);
		lcd_string("Medidor L-C");
		lcd_cmd(LINEA2);
		lcd_string("L:");
		lcd_cmd(LINEA2 + 3);
		lcd_string(med);
		lcd_cmd(LINEA2 + 12);
		lcd_string("mHy");
		_delay_ms(1000);

/*
		XC = Z * sin(angulo * M_PI / 180.0);
		
		C_ = 1 / (2 * M_PI * 1000.0 * XC) * 1000000.0;
		
		dtostrf(C_, 3, 2, med);
		lcd_cmd(CLEAR);
		lcd_cmd(LINEA1 + 2);
		lcd_string("Medidor L-C");
		lcd_cmd(LINEA2);
		lcd_string("C:");
		lcd_cmd(LINEA2 + 3);
		lcd_string(med);
		lcd_cmd(LINEA2 + 12);
		lcd_string("uF");
		_delay_ms(1000);	
*/
	}
}


ISR(TIMER1_CAPT_vect)
{
	if (TCCR1B & (1 << ICES1))
	{
		TCNT1 = 0;
	    TCCR1B &= ~(1 << ICES1);
	}
	
	else
	{
		TCCR1B |= (1 << ICES1);
		captura = ICR1;
	}
}