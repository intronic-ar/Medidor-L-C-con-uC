/*
 * ADC.h
 *
 * Created: 26/10/2022 19:24:07
 *  Author: Fernando
 */ 


#ifndef ADC_H_
#define ADC_H_

#include <avr/interrupt.h>

void ADC_init(void);

uint16_t ADC_read(uint8_t canal);



#endif /* ADC_H_ */