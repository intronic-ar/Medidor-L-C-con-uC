
#include "LCD.h"

void lcd_cmd(unsigned char cmd)
{
	uint8_t init = 0x00;
	init = cmd & 0xF0;							// Separo los primeros 4 bit mas significativos del comando
	init |=	0x0C;								// Enable_H | luz;
	tw_master_transmit(PCF, init, false);
	_delay_ms(1);
	init &= Enable_L;							// Enable low
	tw_master_transmit(PCF, init, false);
	_delay_ms(1);
	init = cmd << 4;							// Separo los bits menos significativos
	init |= 0x0C;								// Enable_H | luz;
	tw_master_transmit(PCF, init, false);		// Enable high
	_delay_ms(1);
	init &= Enable_L;
	tw_master_transmit(PCF, init, false);		// Enable low
	_delay_ms(1);
}


void lcd_data(unsigned char data)
{
	uint8_t init = 0x00;
	init = data & 0xF0;							// Separo los primeros 4 bit mas significativos del comando
	init |=	0x0D;								// Enable_H | RS_H | luz;				
	tw_master_transmit(PCF, init, false);		// 0b xxxx 1101
	_delay_ms(1);
	init &= Enable_L;							// Enable low
	tw_master_transmit(PCF, init, false);		// 0b xxxx 1001
	_delay_ms(1);
	init = data << 4;							// Separo los bits menos significativos
	init |=	0x0D;								// Enable_H | luz | RS_H;			
	tw_master_transmit(PCF, init, false);		// Enable high 0b xxxx 1101 (1100)
	_delay_ms(1);
	init &= Enable_L;
	init |= RS_H;
	tw_master_transmit(PCF, init, false);		// Enable low 0b xxxx 1001  (1000)
	_delay_ms(1);
}


void lcd_string(const char *str)
{
	while (*str)
	{
		lcd_data(*str);
		str++;
	}
}

void lcd_init()
{
	_delay_ms(20);
	lcd_cmd(mode_4b);
	_delay_ms(1);
	lcd_cmd(data_init);
	_delay_ms(1);
	lcd_cmd(data_cursor);
	_delay_ms(1);
	lcd_cmd(data_clear);
	_delay_ms(1);
}