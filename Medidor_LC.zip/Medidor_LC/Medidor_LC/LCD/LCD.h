

#ifndef LCD_H_
#define LCD_H_
#define PCF	0x27
#define Enable_H 0b00000100
#define Enable_L 0b11111011
#define RS_H 0b00000001
#define RS_L 0b11111110
#define mode_4b 0x02		// 4 bit mode (0b0000 0010)
#define data_init 0x28		// Initialization of 16X2 LCD in 4bit mode (0b0010 1000)
#define data_cursor 0x0C	// On-Off cursor (0b0000 1100)
#define data_clear 0x01		// Clear (0b0000 0001)
#define luz 0b00001000		// 0x08

#define LINEA1		0x80
#define LINEA2		0xC0
#define LINEA3		0x94
#define LINEA4		0xD4
#define CLEAR		0x01

#include "twi_master.h"
#include <util/delay.h>

void lcd_cmd(unsigned char cmd);
void lcd_data(unsigned char data);
void lcd_string(const char *str);
void lcd_init();



#endif /* LCD_H_ */